import { useState } from "react";
import { useSistema } from "../../context/SistemaContext";


export default function Operadores(){


const {

operadores,

adicionarCadastro,

removerCadastro

}=useSistema();



const [nome,setNome]=useState("");



function salvar(){


if(!nome){

alert("Digite o nome do operador");

return;

}


adicionarCadastro(
"operadores",
nome
);


setNome("");

}



return(

<div style={{padding:"25px"}}>


<h2>

Operadores

</h2>



<div

style={{

background:"#fff",

padding:"20px",

maxWidth:"400px",

display:"flex",

flexDirection:"column",

gap:"10px"

}}

>


<input

style={{

padding:"10px"

}}

placeholder="Nome do operador"

value={nome}

onChange={(e)=>

setNome(e.target.value)

}

/>



<button

style={{

padding:"12px",

background:"#8000ff",

color:"#fff",

border:"none"

}}

onClick={salvar}

>

Cadastrar

</button>



</div>





<h3>

Operadores cadastrados

</h3>



<table

style={{

width:"100%",

background:"#fff"

}}

>

<thead>

<tr>

<th>

Nome

</th>

<th>

Ação

</th>

</tr>

</thead>



<tbody>


{

operadores.map(item=>(


<tr key={item.id}>


<td>

{item.nome}

</td>


<td>


<button

onClick={()=>removerCadastro(
"operadores",
item.id
)}

>

Excluir

</button>


</td>


</tr>


))

}



</tbody>


</table>



</div>

)

}