import { useState } from "react";
import { useSistema } from "../../context/SistemaContext";


export default function Atividades(){


const {

atividades,

adicionarAtividade,

removerAtividade

}=useSistema();




const [nome,setNome]=useState("");





function salvar(){


if(!nome){

alert("Digite o nome da atividade");

return;

}



adicionarAtividade({

id:Date.now(),

nome

});



setNome("");

}




return(


<div

style={{

padding:"25px"

}}

>



<h2>

Cadastro de Atividades

</h2>





<div

style={{

background:"#fff",

padding:"20px",

borderRadius:"12px",

maxWidth:"500px",

display:"flex",

flexDirection:"column",

gap:"12px"

}}

>


<label>

Nome da atividade

</label>



<input

value={nome}

onChange={(e)=>

setNome(e.target.value)

}

placeholder="Ex: Recebimento, Análise, NFD..."

style={{

padding:"10px",

border:"1px solid #ccc",

borderRadius:"8px"

}}

/>






<button

onClick={salvar}

style={{

padding:"12px",

background:"#8000ff",

color:"#fff",

border:"none",

borderRadius:"8px",

fontWeight:"bold"

}}

>

Cadastrar Atividade

</button>




</div>







<div

style={{

marginTop:"30px"

}}

>


<h3>

Atividades cadastradas

</h3>







<table

style={{

width:"100%",

background:"#fff",

borderCollapse:"collapse"

}}

>


<thead>

<tr>


<th>

Atividade

</th>


<th>

Ação

</th>


</tr>

</thead>





<tbody>


{

atividades.map(item=>(


<tr

key={item.id}

>


<td

style={{

padding:"10px"

}}

>

{item.nome}

</td>



<td>


<button

onClick={()=>removerAtividade(item.id)}

style={{

background:"#e74c3c",

color:"#fff",

border:"none",

padding:"8px",

borderRadius:"6px"

}}

>

Excluir

</button>



</td>


</tr>


))


}





{

atividades.length===0 &&


<tr>


<td

colSpan={2}

style={{

padding:"15px",

textAlign:"center"

}}

>

Nenhuma atividade cadastrada

</td>


</tr>


}



</tbody>



</table>




</div>





</div>


);


}