import { useState } from "react";
import { useSistema } from "../../context/SistemaContext";


export default function Usuarios(){

const {
usuarios,
adicionarUsuario,
removerUsuario

}=useSistema();



const [nome,setNome]=useState("");
const [email,setEmail]=useState("");
const [perfil,setPerfil]=useState("Analista");
const [status,setStatus]=useState("Ativo");



function salvar(){

if(!nome || !email){

alert("Preencha nome e email");

return;

}


const novoUsuario={

id:Date.now(),

nome,

email,

perfil,

status,

dataCadastro:
new Date().toLocaleDateString()

};



adicionarUsuario(novoUsuario);



setNome("");
setEmail("");
setPerfil("Analista");
setStatus("Ativo");

}





return(

<div

style={{
padding:"25px"
}}

>


<h2>

Usuários

</h2>



<div

style={{

background:"#fff",

padding:"20px",

borderRadius:"12px",

boxShadow:"0 3px 10px rgba(0,0,0,0.08)",

display:"flex",

flexDirection:"column",

gap:"12px",

maxWidth:"400px"

}}

>



<label>
Nome
</label>


<input

style={{

padding:"10px",

border:"1px solid #ccc",

borderRadius:"8px"

}}

placeholder="Digite o nome"

value={nome}

onChange={(e)=>
setNome(e.target.value)
}

/>



<label>
Email
</label>


<input

style={{

padding:"10px",

border:"1px solid #ccc",

borderRadius:"8px"

}}

placeholder="Digite o email"

value={email}

onChange={(e)=>
setEmail(e.target.value)
}

/>



<label>
Perfil
</label>


<select

style={{

padding:"10px",

border:"1px solid #ccc",

borderRadius:"8px"

}}

value={perfil}

onChange={(e)=>
setPerfil(e.target.value)
}

>

<option>
Administrador
</option>

<option>
Gestor
</option>

<option>
Analista
</option>

<option>
Operador
</option>


</select>



<label>
Status
</label>


<select

style={{

padding:"10px",

border:"1px solid #ccc",

borderRadius:"8px"

}}

value={status}

onChange={(e)=>
setStatus(e.target.value)
}

>


<option>
Ativo
</option>


<option>
Inativo
</option>


</select>




<button

style={{

marginTop:"10px",

padding:"12px",

background:"#8000ff",

color:"#fff",

border:"none",

borderRadius:"8px",

cursor:"pointer",

fontWeight:"bold"

}}

onClick={salvar}

>

Cadastrar Usuário

</button>



</div>




<div

style={{

marginTop:"30px"

}}

>


<h3>

Usuários cadastrados

</h3>



<table

style={{

width:"100%",

borderCollapse:"collapse",

background:"#fff"

}}

>


<thead>

<tr>


<th

style={{

padding:"10px",

borderBottom:"1px solid #ddd"

}}

>
Nome
</th>


<th

style={{

padding:"10px",

borderBottom:"1px solid #ddd"

}}

>
Email
</th>


<th

style={{

padding:"10px",

borderBottom:"1px solid #ddd"

}}

>
Perfil
</th>


<th

style={{

padding:"10px",

borderBottom:"1px solid #ddd"

}}

>
Status
</th>


<th

style={{

padding:"10px",

borderBottom:"1px solid #ddd"

}}

>
Ação
</th>


</tr>

</thead>



<tbody>


{

usuarios.map((usuario)=>(


<tr key={usuario.id}>


<td

style={{
padding:"10px"
}}

>

{usuario.nome}

</td>


<td

style={{
padding:"10px"
}}

>

{usuario.email}

</td>


<td

style={{
padding:"10px"
}}

>

{usuario.perfil}

</td>


<td

style={{
padding:"10px"
}}

>

{usuario.status}

</td>


<td

style={{
padding:"10px"
}}

>


<button

style={{

background:"#e74c3c",

color:"#fff",

border:"none",

padding:"8px 12px",

borderRadius:"6px",

cursor:"pointer"

}}

onClick={()=>removerUsuario(usuario.id)}

>

Excluir

</button>


</td>


</tr>


))

}


</tbody>


</table>


</div>


</div>


)

}