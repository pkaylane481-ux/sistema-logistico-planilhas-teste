import { useState } from "react";
import { useSistema } from "../../context/SistemaContext";


export default function Marketplaces(){


const {

marketplaces,

adicionarCadastro,

removerCadastro

}=useSistema();




const [nome,setNome]=useState("");

const [status,setStatus]=useState("Ativo");





function salvar(){


if(!nome){

alert("Preencha o marketplace");

return;

}



adicionarCadastro(

"marketplaces",

nome

);



setNome("");

setStatus("Ativo");


}






return(


<div

style={{

padding:"25px"

}}

>


<h2>

Marketplaces

</h2>





<div

style={{

background:"#fff",

padding:"20px",

borderRadius:"12px",

boxShadow:"0 3px 10px rgba(0,0,0,0.08)",

display:"flex",

flexDirection:"column",

gap:"12px",

maxWidth:"400px"

}}

>



<label>

Nome do Marketplace

</label>



<input

style={{

padding:"10px",

border:"1px solid #ccc",

borderRadius:"8px"

}}

placeholder="Digite o marketplace"

value={nome}

onChange={(e)=>

setNome(e.target.value)

}

/>





<label>

Status

</label>



<select

style={{

padding:"10px",

border:"1px solid #ccc",

borderRadius:"8px"

}}

value={status}

onChange={(e)=>

setStatus(e.target.value)

}

>


<option>

Ativo

</option>


<option>

Inativo

</option>


</select>





<button

style={{

marginTop:"10px",

padding:"12px",

background:"#8000ff",

color:"#fff",

border:"none",

borderRadius:"8px",

cursor:"pointer",

fontWeight:"bold"

}}

onClick={salvar}

>


Cadastrar Marketplace


</button>



</div>







<div

style={{

marginTop:"30px"

}}

>


<h3>

Marketplaces cadastrados

</h3>





<table

style={{

width:"100%",

borderCollapse:"collapse",

background:"#fff"

}}

>


<thead>

<tr>


<th

style={{

padding:"10px",

borderBottom:"1px solid #ddd"

}}

>

Nome

</th>



<th

style={{

padding:"10px",

borderBottom:"1px solid #ddd"

}}

>

Data Cadastro

</th>



<th

style={{

padding:"10px",

borderBottom:"1px solid #ddd"

}}

>

Ação

</th>



</tr>

</thead>






<tbody>


{

marketplaces.map((marketplace)=>(


<tr

key={marketplace.id}

>



<td

style={{

padding:"10px"

}}

>

{marketplace.nome}

</td>





<td

style={{

padding:"10px"

}}

>

{marketplace.dataCadastro}

</td>





<td

style={{

padding:"10px"

}}

>


<button

style={{

background:"#e74c3c",

color:"#fff",

border:"none",

padding:"8px 12px",

borderRadius:"6px",

cursor:"pointer"

}}


onClick={()=>


removerCadastro(

"marketplaces",

marketplace.id

)


}


>

Excluir

</button>


</td>


</tr>


))


}




{

marketplaces.length===0 &&


<tr>


<td

colSpan={3}

style={{

padding:"15px",

textAlign:"center"

}}

>


Nenhum marketplace cadastrado


</td>


</tr>


}



</tbody>


</table>



</div>




</div>


)


}